"""
Tests for the Python A2A package.
"""